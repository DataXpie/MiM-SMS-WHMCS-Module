<?php
class msg91 extends MSG91Sms {

    function __construct($message,$gsmnumber,$countryCode=""){
        $this->message = $this->utilmessage($message);
        $this->gsmnumber = $this->utilgsmnumber($gsmnumber);
        $this->countryCode = $countryCode;
    }
	function file_get_contents_curl($url) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       

        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    public function send()
    {
        if ($this->gsmnumber == "numbererror") {
            $log[] = ("Number format error." . $this->gsmnumber);
            $error[] = ("Number format error." . $this->gsmnumber);
            return null;
        }
        $params = $this->getParams();
		
        //$url = "http://107.20.199.106/api/v3/sendsms/plain?user=$params->user&password=$params->pass&sender=$params->senderid&SMSText=" . ($this->message) . "&GSM=$this->gsmnumber&type=longSMS";
        $url = "https://app.mimsms.com/smsAPI?sendsms&apikey=$params->user&apitoken=$params->pass&from=$params->senderid&to=$this->gsmnumber&text=" . ($this->message) . "&type=sms";

        $log[] = "Request url: " . $url;
        $result = simplexml_load_file($url);

        $return = $result;
        $log[] = "server response returned: " . $result;


        


        return array(
            'log' => $log,
            'error' => $error,
            'msgid' => $msgid,
        );
    }

    public function balance()
    {
        return null;
    }

    public function report($msgid)
    {
        return null;
    }


    public function utilgsmnumber($number)
    {
        return $number;
    }

    public function utilmessage($message)
    {
        return $message;
    }
}

return array(
    'value' => 'msg91',
    'label' => 'msg91.com',
    'fields' => array(
        'user', 'pass'
    )
);
